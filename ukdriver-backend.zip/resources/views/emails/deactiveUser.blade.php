<!DOCTYPE html>
<html>
<head>
  <title>You are restricted by Admin</title>
</head>

<body style="max-width: 600px">
<div style="padding: 10px;">
  <div style="text-align: center">
    <p>Deactivated Email</p>
  </div>
  <p style="font-size: 24px">Hi {{$email}}</p>
  <p style="font-size: 16px;">
    You are not allowed to login into UKCourier Website with this email address ({{$email}}).
  </p>
  
  <br/>
  <p style="font-size: 20px;">
    Regards, <br/>
    The UKCourier Team
  </p>
</div>
</body>

</html>
